import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundraiser',
  standalone: true,
  imports: [],
  templateUrl: './fundraiser.component.html',
  styleUrl: './fundraiser.component.css'
})
export class FundraiserComponent implements OnInit{
  donations: any[] = [];
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Replace with your API endpoint
    this.http.get('API_URL/donations?fundraiser_id=1').subscribe((data: any) => {
      this.donations = data;
    });
  }
}
