import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-donation',
  standalone: true,
  imports: [],
  templateUrl: './donation.component.html',
  styleUrl: './donation.component.css'
})
export class DonationComponent implements OnInit{
  donationForm!: FormGroup;
  fundraiserName: string = 'Fundraiser Name'; // This can be fetched dynamically

  constructor(private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    this.donationForm = this.fb.group({
      donorName: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(5)]]
    });
  }
  submitDonation(): void {
    if (this.donationForm.valid) {
      const donationData = this.donationForm.value;

      // API call to submit donation
      this.http.post('API_URL/donations', donationData).subscribe(response => {
        alert(`Thank you for your donation to ${this.fundraiserName}`);
        // Redirect back to fundraiser page
        window.location.href = '/fundraiser';
      });
    } else {
      alert('Minimum donation is 50 Cent');
    }
  }
}
