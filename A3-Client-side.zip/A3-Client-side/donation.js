document.addEventListener('DOMContentLoaded', function() {
  const urlParams = new URLSearchParams(window.location.search);
  const fundraiserId = urlParams.get('id');

  // Fetch the fundraiser details
  fetch(`/api/fundraisers/${fundraiserId}`)
      .then(response => response.json())
      .then(data => {
          if (data && data.length > 0) {
              const fundraiser = data[0];
              document.getElementById('fundraiser-caption').textContent = `Donate to ${fundraiser.CAPTION}`;
              document.getElementById('fundraiser-organizer').textContent = `Organizer: ${fundraiser.ORGANIZER}`;
          }
      })
      .catch(error => console.error('Error fetching fundraiser:', error));

  // Handle donation form submission
  document.getElementById('donation-form').addEventListener('submit', function(event) {
      event.preventDefault();

      // Message element to display errors or success
      const messageElement = document.getElementById('message');

      function displayMessage(text, isError = false) {
          messageElement.textContent = text;
          messageElement.style.color = isError ? 'red' : 'green';
      }

      // Collect form data and perform validation
      const giver = document.getElementById('giver').value.trim();
      const amount = parseFloat(document.getElementById('amount').value);

      if (!giver) {
          displayMessage('Please enter your name.', true);
          return;
      }

      if (isNaN(amount) || amount < 5) {
          displayMessage('Please enter a valid donation amount (minimum 5 AUD).', true);
          return;
      }

      const donationData = {
          giver: giver,
          amount: amount,
          fundraiserId: fundraiserId
      };

      // Submit the donation
      fetch('/api/donation', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(donationData)
      })
      .then(response => response.json())
      .then(() => {
          displayMessage('Thank you for your donation!');
          setTimeout(() => {
              window.location.href = `/fundraiser?id=${fundraiserId}`;
          }, 2000);  // Redirect after 2 seconds
      })
      .catch(error => {
          console.error('Error submitting donation:', error);
          displayMessage('Error submitting your donation. Please try again.', true);
      });
  });
});
